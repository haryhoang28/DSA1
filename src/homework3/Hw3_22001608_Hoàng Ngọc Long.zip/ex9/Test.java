package homework3.ex9;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        OccurOfInteger linkedList = new OccurOfInteger();
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

    }
}
