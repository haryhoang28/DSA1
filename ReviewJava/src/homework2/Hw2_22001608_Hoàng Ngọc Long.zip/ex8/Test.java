package homework2.ex8;

public class Test {
    public static void main(String[] args) {
        String input = "a2b3c4";
        String sortedString = SortStringDigit.sortString(input);
        System.out.println("String after sorting: " + sortedString);
    }
}
