package homework2.ex1;

public interface ISort {
    void sort(int[] array);
}
